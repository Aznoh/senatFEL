Návod pro použití šablony pro tajemníky
=======================================

1) Soubor Sablony.zip rozbalte.
2) Soubor "Usneseni.tex" v adresáři "Usneseni" přejmenujte na "XX-Usneseni.tex",
   kde XX je číslo zasedání. Soubor se zápisem ze zasedání upravte obdobně.

Příkaz, kterým se překládají LaTeXové zdrojové soubory, je vždy uveden
v hlavičce daného souboru. Většinou stačí 'pdflatex' a 'xelatex'.
Automatický skript pro překlad všech dokumentů je './build'.

Pokud chcete spouštět prezentaci z Beameru, doporučuji prohlížeč, který
automaticky pozná změnu PDF souboru, který právě zobrazuje.
Například Evince z GNOME nebo Okular z KDE toto umí.
